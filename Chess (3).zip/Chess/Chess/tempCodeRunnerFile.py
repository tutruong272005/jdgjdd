while running:
        humanTurn=(gs.whiteToMove and playerOne )or(not gs.whiteToMove and playerTwo)
        for e in p.event.get():
            if e.type== p.QUIT:
                running=False
            # mouse handler
            elif e.type == p.MOUSEBUTTONDOWN:
                if not gameOver :
                    location=p.mouse.get_pos()#(x,y) vị trí chuột
                    col=location[0]//SQ_SIZE
                    row=location[1]//SQ_SIZE
                    if sqSelected == (row,col) or col>=8: # ng dùng kik đúp chuột vào ô vuông
                        sqSelected=()# deselect
                        playerClicks=[] #clear player click
                    else:
                        sqSelected=(row,col)
                        playerClicks.append(sqSelected)# append cho cả người 1 và 2 kik chuột
                    if len(playerClicks)==2 and humanTurn:
                        move =ChessEngine.Move(playerClicks[0],playerClicks[1],gs.board)
                        print(move.getChessNotation())
                        for i in range(len(validMoves)):
                            if move == validMoves[i]:
                                gs.makeMove(validMoves[i]) # thực hiện nước đi
                                gs.updateRepetitionTable()  # Cập nhật trạng thái bàn cờ
                                moveMade=True   # đánh dấu nước đi được thực hiện
                                animate=True
                                sqSelected=() # reset user click
                                playerClicks=[]
                        if not moveMade:
                            playerClicks=[sqSelected]
            #key handler
            elif e.type ==p.KEYDOWN:
                if e.key == p.K_z: # nhấn 'z' để đi lại
                    gs.undoMove()
                    
                    moveMade=True
                    animate=False
                    gameOver=False
                    if AIThinking:
                        moveFinderProcess.terminate()
                        AIThinking=False
                    moveUndone=True
                if e.key==p.K_r:# nhấn 'r' để chơi lại ván mới
                    gs=ChessEngine.GameState()
                    validMoves=gs.getValidMoves()
                    gs.updateRepetitionTable()  # Cập nhật lại sau khi undo
                    sqSelected=()
                    playerClicks=[]
                    moveMade=False
                    animate=False
                    gameOver=False
                    if AIThinking:
                        moveFinderProcess.terminate()
                        AIThinking=False
                    moveUndone=True

         #Ai move finder
        if not gameOver and not humanTurn and not moveUndone    :# Nếu game chưa kết thúc và không phải lượt của người chơi
            if not AIThinking:
                AIThinking=True
                print('thinking...')
                returnQueue=Queue() # used to pass data between threads
                moveFinderProcess=Process(target=SmartMoveFinder.findBestMove,args=(gs,validMoves,returnQueue))
                moveFinderProcess.start( )# call findBestMove(gs,validMove,returnQueue)

            if not moveFinderProcess.is_alive():
                print('done thinking')
                AIMove=returnQueue.get()

                if AIMove is None:
                    AIMove =SmartMoveFinder.findRandomMove(validMoves)
                gs.makeMove(AIMove) # Thực hiện nước đi của AI
                moveMade=True# Đánh dấu rằng đã có nước đi được thực hiện
                animate=True# Bật hiệu ứng di chuyển'''
                AIThinking=False

                
    

        # Nếu có nước đi được thực hiện
        if moveMade:
            if animate:
                animateMove(gs.moveLog[-1],screen,gs.board,clock)# Thực hiện hiệu ứng di chuyển
            validMoves = gs.getValidMoves()# Cập nhật lại danh sách nước đi hợp lệ
            moveMade=False  # Đặt lại biến moveMade để chờ nước đi tiếp theo
            animate=False # Đặt lại animate để không chạy animation cho nước đi tiếp theo
            moveUndone=False

        drawGameState(screen,gs,validMoves,sqSelected,moveLogFont)

        '''if gs.checkmate or gs.stalemate:
            gameOver=True
            
            drawEndGameText(screen,text='Stalemate'if gs.stalemate else 'Black wins by checkmate'if gs.whiteToMove else'White wins by checkmate')
            p.display.update()  # Cập nhật màn hình'''
        if gs.checkMade:
            gameOver=True
            if gs.whiteToMove:
                drawEndGameText(screen,'Black wins by checkmate')
            else:
                drawEndGameText(screen,'White wins by checkmate')
        elif gs.staleMade:
            gameOver=True
            drawEndGameText(screen,'Stalemate')
        elif any(value >= 3 for value in gs.repetitionTable.values()):  # Kiểm tra trạng thái lặp 3 lần
            gameOver = True
            drawEndGameText(screen, 'Draw by threefold repetition')


        clock.tick(MAX_FPS)
        p.display.flip()