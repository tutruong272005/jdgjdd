import random

pieceScore={"K":0,"Q":10,"R":5,"B":3,"N":3,"p":1}

knightScores=[[0,0,0,0,0,0,0,0],
              [0,1,1,1,1,1,1,0],
              [0,1,1,2,2,1,1,0],
              [0,1,2,3,3,2,1,0],
              [0,1,2,3,3,2,1,0],
              [0,1,1,2,2,1,1,0],
              [0,1,1,1,1,1,1,0],
              [0,0,0,0,0,0,0,0]]
bishopScore=[[4,3,2,1,1,2,3,4],
             [3,4,3,2,2,3,4,3],
             [2,3,4,3,3,4,3,2],
             [1,2,3,4,4,3,2,1],
             [1,2,3,4,4,3,2,1],
             [2,3,4,3,3,4,3,2],
             [3,4,3,2,2,3,4,3],
             [4,3,2,1,1,2,3,4]]
queenScore=[[1,1,1,3,1,1,1,1],
            [1,2,3,3,3,1,1,1],
            [1,4,3,3,3,4,2,1],
            [1,2,3,3,3,2,2,1],
            [1,2,3,3,3,2,2,1],
            [1,4,3,3,3,4,2,1],
            [1,1,2,3,3,1,1,1],
            [1,1,1,3,1,1,1,1]]
rookScore=[[0,0,1,2,2,1,0,0],
           [0,1,2,3,3,2,1,0],
           [1,2,3,4,4,3,2,1],
           [2,3,4,5,5,4,3,2],
           [2,3,4,5,5,4,3,2],
           [1,2,3,4,4,3,2,1],
           [0,1,2,3,3,2,1,0],
           [0,0,1,2,2,1,0,0]]
whitePawnScores=[[0,0,0,0,0,0,0,0],
                 [1,1,1,1,1,1,1,1],
                 [1,2,2,3,3,2,2,1],
                 [2,3,3,4,4,3,3,2],
                 [3,4,4,5,5,4,4,3],
                 [4,5,6,7,7,6,5,4],
                 [6,7,7,8,8,7,7,6],
                 [0,0,0,0,0,0,0,0]]

blackPawnScores=[[0,0,0,0,0,0,0,0],
                 [1,1,1,0,0,1,1,1],
                 [1,1,2,3,3,2,1,1],
                 [1,2,3,4,4,3,2,1],
                 [2,3,3,5,5,3,3,2],
                 [5,6,6,7,7,6,6,5],
                 [8,8,8,8,8,8,8,8],
                 [8,8,8,8,8,8,8,8]]
piecePositionScores={"N":knightScores,"Q":queenScore,"B":bishopScore,"R":rookScore,"bp":blackPawnScores,"wp":whitePawnScores}

CHECKMATE=1000# Điểm số khi chiếu hết
STALEMATE=0# Điểm số khi hòa
DEPTH =3 #độ sâu tìm kiếm
transposition_table = {}  # Bảng ghi nhớ trạng thái cờ
killer_moves = {}  # Killer moves heuristic
history_heuristic = {}  # Lịch sử nước đi

def quiescence_search(gs, alpha, beta, turnMultiplier):
    stand_pat = turnMultiplier * scoreBoard(gs)
    if stand_pat >= beta:
        return beta
    if alpha < stand_pat:
        alpha = stand_pat
    
    capture_moves = [move for move in gs.getValidMoves() if move.is_capture]
    for move in capture_moves:
        gs.makeMove(move)
        score = -quiescence_search(gs, -beta, -alpha, -turnMultiplier)
        gs.undoMove()
        
        if score >= beta:
            return beta
        if score > alpha:
            alpha = score
    
    return alpha

def findRandomMove(validMoves):# Hàm chọn một nước đi ngẫu nhiên từ danh sách các nước hợp lệ
    # Chọn ngẫu nhiên một nước đi từ danh sách các nước đi hợp lệ
    return validMoves[random.randint(0,len(validMoves)-1)]

def findBestMoveMinMaxNoRecursion(gs,validMoves ):# Hàm tìm nước đi tốt nhất cho người chơi hiện tại
    # Nếu là lượt của Trắng, hệ số là 1, nếu là Đen, hệ số là -1
    turnMultiplier =1 if gs.whiteToMove else -1
    opponentMinMaxScore=-CHECKMATE # Điểm tệ nhất có thể cho đối thủ
    
    bestPlayerMove=None# Biến lưu nước đi tốt nhất của người chơi
    # Trộn danh sách nước đi hợp lệ để tránh kết quả lặp lại khi có nước đi có điểm số giống nhau
    random.shuffle(validMoves)
    for playerMove in validMoves:# Duyệt qua tất cả các nước đi hợp lệ
        gs.makeMove(playerMove)
        opponentsMoves=gs.getValidMoves()# Lấy danh sách nước đi hợp lệ của đối thủ sau nước đi này

         # Nếu ván cờ hòa (stalemate), điểm của đối thủ là 0
        if gs.stalemate:
            opponentMaxScore=STALEMATE
         # Nếu đối thủ bị chiếu hết (checkmate), điểm của đối thủ là -CHECKMATE
        elif gs.checkmate:
            opponentMaxScore=-CHECKMATE
        else:
            opponentMaxScore=-CHECKMATE

            for opponentsMove in opponentsMoves:# Duyệt qua tất cả nước đi của đối th
                gs.makeMove(opponentsMove)
                gs.getValidMoves()

                if gs.checkmate:
                    score=CHECKMATE
                 # Nếu sau nước đi này, ván cờ hòa -> Điểm bằng STALEMATE
                elif gs.stalemate:
                    score=STALEMATE
                else:
                    score=-turnMultiplier*scoreMaterial(gs.board)
                if score>opponentMaxScore:
                    opponentMaxScore=score
                    
                gs.undoMove()   
        ## Nếu điểm đối thủ sau nước đi này thấp hơn điểm tốt nhất của họ trước đó -> Cập nhật nước đi tốt nhất
        if opponentMinMaxScore<opponentMaxScore:
            opponentMinMaxScore=opponentMaxScore
            bestPlayerMove=playerMove
        gs.undoMove()
    return bestPlayerMove# Trả về nước đi tốt nhất tìm được

def findBestMove(gs, validMoves, returnQueue):
    global nextMove, counter
    counter = 0   
    nextMove = None

    if not validMoves:
        returnQueue.put(None)
        return

    # Loại bỏ các nước đi dẫn đến trạng thái đã lặp 2 lần nếu có nước khác
    filteredMoves = []
    for move in validMoves:
        gs.makeMove(move)
        board_state = str(gs.board)
        gs.undoMove()

        if gs.repetitionTable.get(board_state, 0) < 2:
            filteredMoves.append(move)

    # Nếu vẫn còn nước đi hợp lệ sau khi lọc, chỉ xét những nước đó
    if filteredMoves:
        validMoves = filteredMoves  

    # Gọi thuật toán tìm nước đi tốt nhất
    findMoveNegaMaxAlphaBeta(gs, validMoves, DEPTH, -CHECKMATE, CHECKMATE, 1 if gs.whiteToMove else -1)

    print("Số trạng thái đã đánh giá:", counter)
    returnQueue.put(nextMove)



def findMoveMinMax(gs,validMoves,depth,whiteToMove):
    global nextMove
    if depth==0:# Khi đạt đến độ sâu mong muốn, trả về điểm đánh giá của bàn cờ hiện tại
        return scoreMaterial(gs.board)
    
    if whiteToMove:
        maxScore=-CHECKMATE
        for move in validMoves:
            gs.makeMove(move)
            nextMove=gs.getValidMoves() # Lấy danh sách nước đi hợp lệ tiếp theo của đối thủ
            # Gọi đệ quy để tìm điểm số của bàn cờ sau nước đi này, với lượt tiếp theo là Đen
            score=findMoveMinMax(gs,nextMove,depth-1,False)
            if score>maxScore:
                maxScore =score
                if depth== DEPTH:# Nếu đang ở độ sâu gốc, lưu nước đi tốt nhất
                    nextMove=move
            gs.undoMove()
        return maxScore# Trả về điểm số cao nhất tìm được
    
    else:# Nếu là lượt của Đen
        minScore=CHECKMATE
        for move in validMoves:
            gs.makeMove(move)
            nextMove=gs.getValidMoves()
            # Gọi đệ quy để tìm điểm số của bàn cờ sau nước đi này, với lượt tiếp theo là Trắng
            score=findMoveMinMax(gs,nextMove,depth-1,True)
            if score<minScore:
                minScore=score
                if depth==DEPTH:
                    nextMove=move
            gs.undoMove()
        return minScore

def findMoveNegaMax(gs,validMoves,depth,turnMultiplier):
    global nextMove,counter
    counter+=1
    if depth==0:
        return turnMultiplier*scoreBoard(gs)
    maxScore=-CHECKMATE
    for move in validMoves:
        gs.makeMove(move)
        nextMoves=gs.getValidMoves()
        score=-findMoveNegaMax(gs,nextMoves,depth-1,-turnMultiplier)
        if score>maxScore:
            maxScore=score
            if depth==DEPTH:
                nextMove=move
        gs.undoMove()
        
    return maxScore


def findMoveNegaMaxAlphaBeta(gs, validMoves, depth, alpha, beta, turnMultiplier):
    global nextMove, counter
    counter += 1
    
    if depth == 0:
        return turnMultiplier * scoreBoard(gs)

    maxScore = -CHECKMATE
    bestMove = None

    # 🔥 Thêm đánh giá nước đi để ưu tiên tấn công
    for move in validMoves:
        move.score = evaluateMove(gs, move)
    
    # 🔥 Sắp xếp nước đi theo điểm số giảm dần (ưu tiên tấn công)
    validMoves.sort(key=lambda move: move.score, reverse=True)

    for move in validMoves:
        gs.makeMove(move)
        nextMoves = gs.getValidMoves()
        score = -findMoveNegaMaxAlphaBeta(gs, nextMoves, depth - 1, -beta, -alpha, -turnMultiplier)

        gs.undoMove()

        if score > maxScore:
            maxScore = score
            bestMove = move
            if depth == DEPTH:
                nextMove = move

        alpha = max(alpha, maxScore)
        if alpha >= beta:
            break

    return maxScore




def evaluateMove(gs, move):
    """
    Đánh giá nước đi dựa trên:
    - Giá trị quân bị ăn
    - Chiếu tướng
    - Nhập thành
    - Tránh lặp trạng thái bàn cờ
    """
    pieceValue = {"K": 0, "Q": 9, "R": 5, "B": 3, "N": 3, "p": 1}
    attackBonus = 10  # Điểm thưởng khi ăn quân
    checkBonus = 5  # Điểm thưởng khi chiếu tướng
    castlingBonus = 3  # Điểm thưởng khi nhập thành
    repetitionPenalty = -20  # Phạt nếu lặp trạng thái

    score = 0

    # Nếu ăn quân, cộng điểm theo giá trị quân bị ăn
    capturedPiece = gs.board[move.endRow][move.endCol]
    if capturedPiece != "--":
        score += pieceValue.get(capturedPiece[1], 0) + attackBonus

    # Nếu nước đi dẫn đến chiếu tướng, cộng điểm
    gs.makeMove(move)
    if gs.inCheck():
        score += checkBonus
    gs.undoMove()

    # Nếu nhập thành, cộng điểm
    if move.isCastleMove:
        score += castlingBonus

    # Nếu nước đi lặp trạng thái cũ, trừ điểm
    board_state = str(gs.boardAfterMove(move))
    if gs.repetitionTable.get(board_state, 0) > 1:
        score += repetitionPenalty

    return score

def scoreBoard(gs):
    if gs.checkmate:
        return -CHECKMATE if gs.whiteToMove else CHECKMATE
    if gs.stalemate:
        return STALEMATE
    
    score = 0
    for row in range(8):  # Giả sử bàn cờ 8x8
        for col in range(8):
            square = gs.board[row][col]
            if square != "--":
                # Tính điểm vị trí (mặc định 0 cho vua)
                piece_type = square[1]
                piecePositionScore = piecePositionScores.get(piece_type, [[0]*8]*8)[row][col] if piece_type != 'K' else 0
                # Tính điểm tổng
                piece_value = pieceScore[piece_type]
                if square[0] == 'w':
                    score += piece_value + piecePositionScore * 0.1
                else:  # square[0] == 'b'
                    score -= piece_value + piecePositionScore * 0.1

    return score

def scoreMaterial(board):
    score = 0
    for row in range(8):
        for col in range(8):
            square = board[row][col]
            if square != "--":
                piece_value = pieceScore[square[1]]
                if square[0] == 'w':
                    score += piece_value
                elif square[0] == 'b':
                    score -= piece_value
    return score